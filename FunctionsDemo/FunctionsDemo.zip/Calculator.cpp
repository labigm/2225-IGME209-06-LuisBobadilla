#include "FunctionsDemo.h"
int AddNumbers(int a, int b)
{
	return a + b;
}